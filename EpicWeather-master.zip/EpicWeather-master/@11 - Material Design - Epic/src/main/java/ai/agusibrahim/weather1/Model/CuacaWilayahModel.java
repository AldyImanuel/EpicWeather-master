package ai.agusibrahim.weather1.Model;

public class CuacaWilayahModel
{
	public PlaceModel place;
	public CuacaModel model;

	public CuacaWilayahModel(PlaceModel place, CuacaModel model) {
		this.place=place;
		this.model=model;
	}
}
